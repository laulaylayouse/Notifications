package com.example.notificationsapp_laila

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title="App"

        var Name = findViewById<EditText>(R.id.EditText)
        var submit = findViewById<Button>(R.id.submit)

        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        submit.setOnClickListener {
            var input_EditText = Name.text.toString()

            if (input_EditText.isNotEmpty()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    var notificationChannel = NotificationChannel(
                        "myapp.notifications", "Notification App Example",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    notificationManager.createNotificationChannel(notificationChannel)
                    var builder = Notification.Builder(this, "myapp.notifications")
                        .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                        .setContentTitle("My Notification")
                        .setContentText("Hello $input_EditText !")
                    notificationManager.notify(1234, builder.build())
                } else {
                    var builder = Notification.Builder(this)
                        .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                        .setContentTitle("My Notification")
                        .setContentText("Hello $input_EditText")
                    notificationManager.notify(1234, builder.build())
                }

            }
            else {
                Toast.makeText(this, "Please Enter a message ", Toast.LENGTH_LONG).show()
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.Bonus -> {
                val intent = Intent(this@MainActivity,NotificationsApp_Bonus::class.java)
                startActivity(intent)
                Toast.makeText(this,"NotificationsApp_Bonus" , Toast.LENGTH_SHORT)

            }
            else -> return super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }

}